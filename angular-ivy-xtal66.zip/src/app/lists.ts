export interface List {
  id: number;
  name: string;
}
