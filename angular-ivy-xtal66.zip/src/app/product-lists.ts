import { List } from './lists';

export const LIST: List[] = [
  { id: 1, name: 'samsung' },
  { id: 2, name: 'apple' },
  { id: 3, name: 'google' },
  { id: 4, name: 'microsoft' },
  { id: 5, name: 'adobe' },
  { id: 6, name: 'amazon' },
  { id: 7, name: 'facebook' },
  { id: 8, name: 'oracle' },
  { id: 9, name: 'sap' },
  { id: 10, name: 'sony' }
];